/***********************************************************************/
/*                                                                     */
/*   sa_input.c                                                        */
/*                                                                     */
/*   This program handels the input file which contains parameters     */
/*                                                                     */
/***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "head.h"
#include "util.h"

static unsigned long pos = 0;
static char line[100000];
static int repeatNumber;

/*---------------------------------------
  add multiplier values to tree node
  --------------------------------------*/

void add_field(TNODE *n, double* (*get_field)(TNODE *)) {
    if (n == NULL) return ;
    char na[100000];
    if ( line[pos] == '(' ) {
        pos++;
        if (n->lchild != NULL )
            add_field(n->lchild, get_field);
        if (line[pos] != ',')
            fatalf("Error1 %s", line + pos);
        pos++;
        if (n->rchild != NULL)
            add_field(n->rchild, get_field);
        if (line[pos] != ')')
            fatalf("Error2 %s", line + pos);
        pos++;
        sscanf(line + pos, ":%lf", get_field(n));
        pos++;
        while (isdigit(line[pos]) || line[pos] == '.')
            pos++;
        return ;
    }
    sscanf(line + pos, "%[^:]:%lf", na, get_field(n));
    if (strcmp(na, n->name))
        fatalf("Name mismatch %s %s\n", na, n->name);
    while (line[pos] != ':')
        pos++;
    pos++;
    while (isdigit(line[pos]) || line[pos] == '.')
        pos++;
}

void init_field(TNODE *n, double* (*get_field)(TNODE *), double value) {
    if (n->lchild != NULL) {
        if (n->rchild != NULL)
            init_field(n->rchild, get_field, value);
        init_field(n->lchild, get_field, value);
    }
    *(get_field(n)) = value;
}

double* getInsertionMultiplier(TNODE *n) {
    return &(n->ins_multiplier);
}

double* getDeletionMultiplier(TNODE *n) {
    return &(n->del_multiplier);
}

double* getInversionMultiplier(TNODE *n) {
    return &(n->inv_multiplier);
}

double* getRepeatInsertion(TNODE *n) {
    return &(n->rp_insertion[repeatNumber]);
}

/*--------------------------------------
  read in multipliers, add to tree nodes
  -------------------------------------*/

void read_extra_informations(char *filename) {
    FILE *f = ckopen(filename, "r");
    char tag[10000];
    int i;
    /* set default values */
    init_field(TheTree, getInsertionMultiplier, 1);
    init_field(TheTree, getDeletionMultiplier, 1);
    init_field(TheTree, getInversionMultiplier, 1);
    RepeatNum = 0;
    while (fscanf(f, "%s = %[^\n]\n", tag, line) != EOF) {
        if (tag[0] == '/' && tag[1] == '/') {
            fscanf(f, " %s", line);
            continue;
        }
        if (!strcmp(tag, "InsertionMultiplier")) {
            pos = 0;
            add_field(TheTree, getInsertionMultiplier);
            continue;
        }
        if (!strcmp(tag, "DeletionMultiplier")) {
            pos = 0;
            add_field(TheTree, getDeletionMultiplier);
            continue;
        }
        if (!strcmp(tag, "InversionMultiplier")) {
            pos = 0;
            add_field(TheTree, getInversionMultiplier);
            continue;
        }
        if (sscanf(tag, "RepeatConsensus%d", &i) == 1) {
            strcpy(RepeatConsensus[i], line);
            if (i >= (signed)RepeatNum)
                RepeatNum = i + 1;
            continue;
        }
        if (sscanf(tag, "RepeatInsertion%d", &i) == 1) {
            repeatNumber = i;
            pos = 0;
            add_field(TheTree, getRepeatInsertion);
            continue;
        }
        /* printf("Unknown line : %s = %s \n", tag, line); */
        /* exit(1); */
    }
    fclose(f);
    (void)fprintf(stderr, " Done!\n");
}

/*-------------------------------
  modify tree related parameters
 -------------------------------*/

void modify_para_file(char *filenamein, char *filenameout) {
    char line[100000], tree[100000];
    int nb_dup = 3;
    int x, i, first;
    int counter = 0, global_counter = 0;
    int myid = 0, add_par = 1;
    float l;
    FILE *f = ckopen(filenamein, "r");
    FILE *o = ckopen(filenameout, "w");

    while (fscanf(f, "%[^\n]\n", line) != EOF) {
        first = 1;
        myid = 0;
        counter = 0;
        if (sscanf(line, "TheTree = %s", tree)
            || sscanf(line, "InsertionMultiplier = %s", tree)
            || sscanf(line, "DeletionMultiplier = %s", tree)
            || sscanf(line, "InversionMultiplier = %s", tree)
            || sscanf(line, "RepeatInsertion%d = %s", &x, tree)) {
            char name[100000];
            i = 0;
            add_par = 1;
            sscanf(line, "%s", name);
            fprintf(o, "%s = ", name);
            while (tree[i] != '\0') {
                if (tree[i] == '(') {
                    add_par = 1;
                    if (first) {
                        fprintf(o, "(");
                        first = 0;
                        i++;
                        continue;
                    }
                    for (x = 1; x < nb_dup; x++)
                        fprintf(o, "(");
                    i++;
                    fprintf(o, "(ANCESTRAL%d:0,(", myid);
                    myid++;
                    continue;
                }
                if (tree[i] == ')') {
                    if (tree[i + 1] != 0 && tree[i + 1] != '\n' && tree[i + 1] != ';')
                        fprintf(o, "):0)" );
                    else
                        fprintf(o, ")");
                    i++;
                    continue;
                }
                if (tree[i] == ':') {
                    i++;
                    sscanf(tree + i, "%f", &l);
                    for (x = 1; x < nb_dup; x++) {
                        if (line[0] == 'T' && line[1] == 'h' && line[2] == 'e')
                            fprintf(o, ":%f,DUP%d:0)", l / nb_dup, counter);
                        else
                            fprintf(o, ":%f,DUP%d:0)", l, counter);
                        counter++;
                        global_counter = counter;
                    }
                    if (line[0] == 'T' && line[1] == 'h' && line[2] == 'e')
                        fprintf(o, ":%f", l / nb_dup);
                    else
                        fprintf(o, ":%f", l);
                    while (tree[i] == '.' || isdigit(tree[i]))
                        i++;
                    continue;
                }
                if (tree[i] == ',') {
                    fprintf(o, ",");
                    i++;
                    continue;
                }
                if (isalpha(tree[i])) {
                    add_par = 0;
                    for (x = 1; x < nb_dup; x++)
                        fprintf(o, "(");
                    while (tree[i] != ':') {
                        fprintf(o, "%c", tree[i]);
                        i++;
                    }
                    continue;
                }
                fatalf("Should not be here %s", tree + i);
            }
            fprintf(o, "\n");
            continue;
        }
        if (sscanf(line, "SequenceNum = %d", &SequenceNum))
            continue;
        fprintf(o, "%s\n", line);
    }
    fprintf(o, "SequenceNum = %d\n", SequenceNum + global_counter + SequenceNum - 2);
    fclose(o);
    fclose(f);
}

/* the freq_str should be in this way: [f1,f2,f3,...,fn]
   Return double array of frequencies of ACGT..  */

double* get_freq(char *freq_str) {
    double *freq = (double *)ckalloc(sizeof(double) * MAX_ALPH);
    char tmp_buf[20], *endp;
    double tmp_freq;
    int i, j, count;
    i = count = 0;
    while (freq_str[i] != '\0') {
        if (freq_str[i] == '[')
            i++;
        j = 0;
        while (freq_str[i] != ',' && freq_str[i] != ']') {
            tmp_buf[j] = freq_str[i];
            j++; i++;
        }
        i++;
        tmp_buf[j] = '\0';
        tmp_freq = strtod(tmp_buf, &endp);
        freq[(int)TheAlphabet[count++]] = tmp_freq;
    }
    return freq;
}

/* the func_str should be in this way: [f1,f2,f3,...,fn]
   Return double array of length distributions of each operation..  */

double* get_func(char *func_str, int *dim) {
    /* Get Dimension first */
    int i = 0, count = 0, j;
    double *func;
    char tmp_buf[20], *endp;
    double tmp_freq;

    while (func_str[i] != '\0') {
        if (func_str[i++] == ',')
            count++;
    }
    *dim = count + 1;
    func = (double *)ckalloc((size_t)(sizeof(double) * (*dim)));
    i = count = 0;
    while (func_str[i] != '\0') {
        if (func_str[i] == '[')
            i++;
        j = 0;
        while (func_str[i] != ',' && func_str[i] != ']') {
            tmp_buf[j] = func_str[i];
            j++; i++;
        }
        i++;
        tmp_buf[j] = '\0';
        tmp_freq = strtod(tmp_buf, &endp);
        func[count++] = tmp_freq;
    }
    return func;
}

double *do_freq_accum(double *org, int dim, int bnum) {
    int i;
    double *new = (double *)ckalloc((size_t)(sizeof(double) * dim));

    if (org == NULL)
        fatal("Please specify the frequency");

    new[(int)TheAlphabet[0]] = org[(int)TheAlphabet[0]];
    for ( i = 1; i < bnum; i++)
        new[(int)TheAlphabet[i]] = new[(int)TheAlphabet[i - 1]] + org[(int)TheAlphabet[i]];
    new[SUMM] = new[(int)TheAlphabet[bnum - 1]];
    ckfree(org);

    return new;
}

double *do_func_accum(double *org, int dim) {
    int i;
    double *new = (double *)ckalloc((size_t)(sizeof(double) * (dim + 1)));

    if (org == NULL)
        fatal("Please specify the function");

    new[1] = org[0];
    for ( i = 2; i <= dim; i++)
        new[i] = new[i - 1] + org[i - 1];
    new[SUMM] = new[dim];
    ckfree(org);

    return new;
}

/*---------------
  get parameters
 ----------------*/

void read_in_para(char *para_file) {
    FILE *pfile;
    char buf[100000];
    char tmp_buf[100000];

    pfile = ckopen(para_file, "r");

    print_argv0();
    (void)fprintf(stderr, "Reading parameters....");

    while (fscanf(pfile, "%[^\n]\n", buf) != EOF) {
        if (buf[0] == '#')
            continue;
        if (sscanf(buf, "SequenceLen = %lu", &SequenceLen))
            continue;
        if (sscanf(buf, "SequenceNum = %d", &SequenceNum))
            continue;
        if (sscanf(buf, "TransitionBias = %lf", &TransitionBias))
            continue;
        if (sscanf(buf, "TheInsertThreshold = %lf", &TheInsertThreshold)) {
            if (TheInsertThreshold >= 1 || TheInsertThreshold <= 0)
                fatal("\nTheInsertThreshold: Incorrect Value");
            continue;
        }
        if (sscanf(buf, "TheDeleteThreshold = %lf", &TheDeleteThreshold)) {
            if (TheDeleteThreshold >= 1 || TheDeleteThreshold <= 0)
                fatal("TheDeleteThreshold: Incorrect Value");
            continue;
        }
        if (sscanf(buf, "TheInvertThreshold = %lf", &TheInvertThreshold)) {
            if (TheInvertThreshold >= 1 || TheInvertThreshold <= 0)
                fatal("TheInvertThreshold: Incorrect Value");
            continue;
        }
        if (sscanf(buf, "MinInvLength = %d", &MinInvLength)) {
            if (MinInvLength > 5000 || MinInvLength < 50)
                fatal("MinInvLength: make it between (50, 5000) ");
            continue;
        }
        if (sscanf(buf, "TheDNAmodel = %s", tmp_buf)) {
            TheDNAmodel = copy_string(tmp_buf);
            continue;
        }
        if (sscanf(buf, "TheAlphabet = %s", tmp_buf)) {
            TheAlphabet = copy_string(tmp_buf);
            continue;
        }
        if (sscanf(buf, "TheFreq = %s", tmp_buf)) {
            TheFreq = get_freq(tmp_buf);
            TheFreq = do_freq_accum(TheFreq, MAX_ALPH, BASE_NUM);
            continue;
        }
        if (sscanf(buf, "TheInsFunc = %s", tmp_buf)) {
            TheInsFunc = get_func(tmp_buf, &InsFuncDim);
            TheInsFunc = do_func_accum(TheInsFunc, InsFuncDim);
            continue;
        }
        if (sscanf(buf, "TheDelFunc = %s", tmp_buf)) {
            TheDelFunc = get_func(tmp_buf, &DelFuncDim);
            TheDelFunc = do_func_accum(TheDelFunc, DelFuncDim);
            continue;
        }
        if (sscanf(buf, "TheInvFunc = %s", tmp_buf)) {
            TheInvFunc = get_func(tmp_buf, &InvFuncDim);
            TheInvFunc = do_func_accum(TheInvFunc, InvFuncDim);
            continue;
        }
        if (sscanf(buf, "TheTree = %s", tmp_buf)) {
            TheTree = get_tree(tmp_buf);
            continue;
        }
    }
    fclose(pfile);
    if ((unsigned)MinInvLength * 5 > SequenceLen)
        fatal("MinInvLength is too long compared with SequenceLen");
    return ;
}

/*---------------------
  create root sequence
 ----------------------*/

void create_root(void) {
    unsigned long i;
    ckfree(TheSequence);
    TheSequence = (char *)ckalloc((size_t)(SequenceLen + 1));

    for (i = 0; i < SequenceLen; i++)
        TheSequence[i] = get_random_char(RNDCHAR, 0);
    TheSequence[SequenceLen] = '\0';

    return ;
}

/*----------------------------------------
  create mutation probability of root seq
 -----------------------------------------*/

void create_mutation_prob(void) {
    unsigned long i;

    ckfree(TheMutationProbability);
    TheMutationProbability = (double *)ckalloc((size_t)(sizeof(double) * SequenceLen));

    /* all 1.0 at the moment, how to determine? */

    for (i = 0; i < SequenceLen; i++)
        TheMutationProbability[i] = 1.0;

    return ;
}

/*----------------------------------------
  free all allocated space, before say bye
 -----------------------------------------*/

void free_para_space(void) {
    free(TheSequence);
    free(TheRateMatrix);
    free(TheMatrix);
    free(TheAlphabet);
    free(TheFreq);
    free(TheInsFunc);
    free(TheDelFunc);
    free(TheInvFunc);
    free(TheDNAmodel);
    free(TheMutationProbability);
    free_tree_space(TheTree); /* free the tree structure, alignment
                                     components have been released already */
}


