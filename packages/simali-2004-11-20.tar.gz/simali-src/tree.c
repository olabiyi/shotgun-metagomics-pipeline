/***********************************************************************/
/*                                                                     */
/*   tree.c                                                            */
/*                                                                     */
/*   build tree structure, and free tree space                         */
/*                                                                     */
/***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "head.h"
#include "util.h"

void free_comp_list(SEQCOMP *p) {
    SEQCOMP *q;
    while (p->next != NULL) {
        q = p->next;
        p->next = NULL;
        ckfree(p->text);
        p->text = NULL;
        ckfree(p);
        p = q;
    }
    ckfree(p->text);
    p->text = NULL;
    ckfree(p);
    p = NULL;
    return ;
}

static void remove_subtree(TNODE *node) {
    if (node == NULL)
        return ;
    remove_subtree(node->lchild);
    remove_subtree(node->rchild);
    ckfree(node->name);
    free(node);
    return ;
}

void free_tree_space(TNODE *node) {
    remove_subtree(node);
    return ;
}

void free_tree_ali(TNODE *node) {
    if (node == NULL) return ;
    if (node->alignment != NULL)
        free_comp_list(node->alignment);
    node->visited = 0;
    node->seqlen = 0;
    ckfree(node->mut_prob);
    free_tree_ali(node->lchild);
    free_tree_ali(node->rchild);
    return ;
}

/* return the tree in tree structure based upon the NEWICK tree format
   in the input parameter file. */

TNODE* get_tree(char *tree_str) {
    /* now just assume that the NEWICK tree is correct. */
    TNODE *stack[200], *p = NULL, *q;
    char ch, buf[20], buf2[20], *str, *endp;
    int k = 0, top = 0, bidx = 0, b2idx = 0;
    int count = 1, nidcount = 0;
    double dc = 0.0;

    /* parse the tree string, build the tree */

    ch = tree_str[0];

    while (ch != '\0') {
        if (isalpha(ch)) {
            p = (TNODE *)ckalloc(sizeof(TNODE));
            p->name = NULL;
            p->distance = 0;
            p->nid = nidcount++;
            p->lchild = NULL;
            p->rchild = NULL;
            buf[bidx++] = ch;
            ch = tree_str[++k];
            while (ch != ':') {
                buf[bidx++] = ch;
                ch = tree_str[++k];
            }
            buf[bidx] = '\0';
            bidx = 0;
            str = copy_string(buf);
            p->name = str;
        }
        if (ch == ':') {
            ch = tree_str[++k];
            while (ch != ',' && ch != ')') {
                buf2[b2idx++] = ch;
                ch = tree_str[++k];
            }
            buf2[b2idx] = '\0';
            dc = strtod(buf2, &endp);
            b2idx = 0;
        }
        switch (ch) {
            case '(': {
                p = (TNODE *)ckalloc(sizeof(TNODE));
                str = (char *)ckalloc(sizeof(char) * 4);
                sprintf(str, "IN%d", count++);
                p->name = str;
                p->distance = 0;
                p->father = NULL;
                p->lchild = NULL;
                p->rchild = NULL;
                p->visited = 0;
                p->nid = nidcount++;
                stack[top++] = p;
                break;
            }
            case ',': {
                q = stack[top - 1];
                q->lchild = p;
                p->father = q;
                p->distance = dc;
                break;
            }
            case ')': {
                q = stack[--top];
                q->rchild = p;
                p->father = q;
                p->distance = dc;
                p = q;
                break;
            }
            default: ; /* do nothing */
        }
        ch = tree_str[++k];
    }
    return p;
}

