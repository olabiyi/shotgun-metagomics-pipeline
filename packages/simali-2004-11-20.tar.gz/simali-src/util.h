/* util.h */

#ifndef __UTIL_H__
#define __UTIL_H__

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <math.h>     /* HUGE_VAL */
#include <limits.h>   /* INT_MAX, INT_MIN, LONG_MAX, LONG_MIN, etc. */
#include <assert.h>
#include <errno.h>

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE (!FALSE)
#endif

#ifndef BOOL
#define BOOL unsigned int
#endif

#define MAX(X,Y) (((X) > (Y)) ? (X) : (Y))
#define MIN(X,Y) (((X) < (Y)) ? (X) : (Y))
#define ROUND(X) ((unsigned long)((X) + 0.5))

typedef int bool;
extern char *argv0;

void print_argv0(void);
void print_a_line(void);

#ifdef __GNUC__     /* avoid some "foo might be used uninitialized" warnings */
void fatal(const char *msg) __attribute__ ((noreturn));
void fatalf(const char *fmt, ...) __attribute__ ((noreturn));
void fatalfr(const char *fmt, ...) __attribute__ ((noreturn));
#else
void fatal(const char *msg);
void fatalf(const char *fmt, ...);
void fatalfr(const char *fmt, ...);
#endif

FILE *ckopen(const char *name, const char *mode);
void ckfree(void* p);
void *ckalloc(size_t amount);
void *ckallocz(size_t amount);
void *ckrealloc(void * p, size_t size);
bool same_string(const char *s, const char *t);
char *copy_string(const char *s);
char *copy_substring(const char *s, int n);
unsigned int roundup(unsigned int n, unsigned int m);

double get_random_double(double bound);
unsigned long get_random_int(unsigned long bound);
char get_random_char(char old_value, double dist);

unsigned long count_base(char *p, unsigned long len);

char complement(char a);
char *rev_comp_string(char *s);

void do_cmd(const char *fmt, ...);

#endif

