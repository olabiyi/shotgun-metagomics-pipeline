/********************************************************************/
/*                                                                  */
/*   sa_main.c                                                      */
/*                                                                  */
/*   Main file and Command Line Interface to the simali program.    */
/*                                                                  */
/********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "head.h"
#include "util.h"

int dataset_num = 1;           /* default value of dataset number */
unsigned long SequenceLen;     /* length of root sequence */
int SequenceNum;
TNODE *TheTree;                /* the phylogenetic tree used in the program */
char *TheSequence = NULL;      /* the root sequence */
char *TheDNAmodel;             /* name of the model, only handles HKY in this version! */
double **TheRateMatrix;        /* the HKY model */
double MeanSubstitution = 0.01342302;  /* used in HKY  */
double TransitionBias;         /* used in HKY */
double **TheMatrix;            /* values accumulated based on TheRateMatrix */
char *TheAlphabet;             /* alphabet "A C G T" for DNA sequences */
double *TheFreq;               /* frequency of each character in alphabet */
double *TheInsFunc;            /* insertion length distribution function */
double *TheDelFunc;            /* deletion length distribution function */
double *TheInvFunc;            /* inversion length distribution function */
int InsFuncDim = 0;            /* dimension of insertion function. init 0 */
int DelFuncDim = 0;            /* dimension of deletion function. init 0 */
int InvFuncDim = 0;            /* dimension of inversion function. init 0 */
int MinInvLength;              /* minimum length of inversions */
double TheInsertThreshold;     /* insertion probability */
double TheDeleteThreshold;     /* deletion probability */
double TheInvertThreshold;     /* inversion probability */
double *TheMutationProbability = NULL;  /* mutation probability of each position in root sequence */
double MotifLossProb = 0.0;
unsigned int RepeatNum;        /* number of interspersed repeats families */
char RepeatConsensus[100][10000];  /* repeat family sequences */

char *argv0;                   /* argv[0], name of the program */

static const char Usage[] =     /* help message */
"%s [version %1.1f]: a program generating simulated 'true' alignment.\n\
USAGE: %s parameter_file [N=?]\n\
       - parameter_file contains parameters that will be used in the program.\n\
         See README.pdf file to know how to set the parameters.\n\
       - optional argument N is the number of dataset you need.\n\
         The default value is 1.\n\
       %s --help\n\
       - display this help and exit.\n\
NOTE: Make sure you are running %s in a clean directory, where \"dataset\" is\n\
      not the prefix of any sub-dir's name.\n";

/*--------------------  MAIN  ----------------------*/
int main (int argc, char* argv[]) {
    char buf[100];
    int i;

    argv0 = copy_string(argv[0]);;
    TheTree = NULL;

    if (argc == 1) {
        (void)fprintf(stderr, "%s [version %1.1f]: too few arguments\n", argv0, VERSION);
        (void)fprintf(stderr, "Try `%s --help' for more information.\n", argv0);
        exit(1);
    }
    if (argc > 3 ) {
        (void)fprintf(stderr, "%s [version %1.1f]: too many arguments\n", argv0, VERSION);
        (void)fprintf(stderr, "Try `%s --help' for more information.\n", argv0);
        exit(1);
    }
    if (argc == 3) {
        sprintf(buf, "%s", argv[2]);
        if (sscanf(buf, "N=%d", &dataset_num)) {
            if (dataset_num <= 0)
                fatal("[N=?] Number of dataset should be larger than 1.");
            print_argv0();
            (void)fprintf(stderr, "OK, %s will generate %d datasets for you.\n", argv0, dataset_num);
            //print_a_line();
        } else
            fatal("[N=?] Number of dataset should be an integer ( N >=1 )");
    }
    if (same_string(argv[1], "--help")) {
        (void)fprintf(stderr, Usage, argv0, VERSION, argv0, argv0, argv0);
        exit(0);
    }
    if (dataset_num == 1 && argc == 2) {
        print_argv0();
        (void)fprintf(stderr, "OK, %s will generate %d dataset for you.\n", argv0, dataset_num);
        //print_a_line();
    }

    /* the simulation program starts to work */

    sprintf(buf, "_modified_para_file_");
    modify_para_file(argv[1], buf);      /* preprocess the parameter file */

    argv[1] = (char *)ckalloc(100);
    sprintf(argv[1], "%s", buf);

    read_in_para(argv[1]);               /* read parameters and create the tree */

    read_extra_informations(argv[1]);    /* set multipliers on tree nodes
                                            and read in interspersed repeat family */

    /* generate certain number of datasets */

    for (i = 1; i <= dataset_num; i++) {
        print_a_line();
        print_argv0();
        (void)fprintf(stderr, "Generating dataset # %03d\n", i);

        srand48(getpid() * time(NULL));   /* set seed for random methods */

        create_root();                    /* create root sequence */
        create_mutation_prob();           /* create mutation prob of root sequence */

        evolve_through_tree();            /* evolve through the tree,
                                             get sequences and alignment */
        print_result(i);                  /* ouput alignment in maf format
                                             and sequences in fasta format */
        free_tree_ali(TheTree);           /* free alignment and sequence space of each node
                                             in the tree, keep the tree structure and other 
                                             parameter, e.g. name, function & multipliers */
    }

    free_para_space();                   /* free all space allocated in the program */

    /* simulation is completed */

    do_cmd("rm -f _modified_para_file_");
    print_a_line();
    print_argv0();
    (void)fprintf(stderr, "%d datasets ready. Enjoy!\n", dataset_num);
    free(argv0);

    return 0;
}
/*--------------------  MAIN  ----------------------*/

