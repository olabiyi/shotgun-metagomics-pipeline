/***********************************************************************/
/*                                                                     */
/*   sa_evolve.c                                                       */
/*                                                                     */
/*   This program deals with evolution through the phylogenetic tree,  */
/*   Operations include subsitution, deletion, insertion of random     */
/*   bases, insertion of interspersed repeats, and inversions          */
/*                                                                     */
/***********************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include "util.h"
#include "head.h"

#define RANDINS 1000
static unsigned long myroot_length = 0;

/*-------------------------
      do substitution 
 -------------------------*/

void do_substitution(TNODE *node) {
    unsigned long j, len, count = 0;
    int islow = FALSE;
    char prech, postch, newchar, oldchar;
    SEQCOMP *p;

    prech = RNDCHAR;

    for (p = node->alignment; p != NULL; p = p->next) {
        len = strlen(p->text);
        for (j = 0; j < len && count < node->seqlen; j++) {
            if (p->text[j] == '-')
                continue;
            else {
                oldchar = p->text[j];
                if ( !isupper(oldchar) ) {
                    islow = TRUE;
                    oldchar = toupper(oldchar);
                }
                if (oldchar == 'C') {
                    if (j == len - 1) {
                        if (p->next != NULL)
                            postch = p->next->text[0];
                        else
                            postch = RNDCHAR; /* the last ch */
                    } else
                        postch = p->text[j + 1];

                    if (toupper(postch) == 'G')
                        newchar = get_random_char(oldchar, CPG_MULTIPLICATIVE_FACTOR
                                                  * node->distance * node->mut_prob[count++]);
                    else
                        newchar = get_random_char(oldchar, node->distance
                                                  * node->mut_prob[count++]);
                } else {
                    if (oldchar == 'G' && toupper(prech) == 'C')
                        newchar = get_random_char(oldchar, CPG_MULTIPLICATIVE_FACTOR
                                                  * node->distance * node->mut_prob[count++]);
                    else
                        newchar = get_random_char(oldchar, node->distance
                                                  * node->mut_prob[count++]);
                }
            }
            if (islow) {
                newchar = tolower(newchar);
                islow = FALSE;
            }
            p->text[j] = newchar;   /* point mutation */
            prech = newchar;
        }
    }
    return ;
}

/* insert dashes to visited tree nodes
   pos -- the insertion position in the alignment
   inslen -- the length of dashes that will be inserted
   nid -- the node ID of the do_insertion node */

void insert_dash(TNODE *node, unsigned long pos, unsigned long inslen, int nid) {
    char *r, *theinsert;
    unsigned long offset, pastart, i, olen;

    SEQCOMP *p, *q;

    if (node == NULL || node->visited == 0 || node->nid == nid)
        return ;

    p = node->alignment;
    q = p->next;
    while (q != NULL && (pos < p->alistart || pos > p->aliend)) {
        p = q;
        q = q->next;
    }

    offset = pos - p->alistart;
    olen = p->aliend - p->alistart + 1;
    if (p->strand == '-')
        offset = (p->aliend - p->alistart + 1) - offset;
    pastart = p->alistart;
    p->aliend += inslen;
    theinsert = (char *)ckalloc((size_t)(inslen + 1));
    for (i = 0; i < inslen; i++)
        theinsert[i] = '-';
    theinsert[i] = '\0';
    r = (char *)ckalloc((size_t)(olen + inslen + 1));
    if (offset != 0)
        memcpy(r, p->text, (size_t)offset);
    memcpy(r + offset, theinsert, (size_t)inslen);
    if (olen != offset)
        strcpy(r + offset + inslen, p->text + offset);
    else
        r[offset + inslen] = '\0';
    r[olen + inslen] = '\0';  /* delete it */
    free(p->text);
    p->text = r;
    free(theinsert);

    for (p = node->alignment; p != NULL; p = p->next) {
        if (p->alistart > pastart) {
            p->alistart += inslen;
            p->aliend += inslen;
        }
    }
    /* insert dashes to other visited nodes in the tree */
    insert_dash(node->lchild, pos, inslen, nid);
    insert_dash(node->rchild, pos, inslen, nid);

    return ;
}

/*-------------------------
      do insertion 
 -------------------------*/

void do_insertion(TNODE *node, unsigned int repeat_id) {
    double insert_prob, total, *old_vector, inslen, threshold;
    unsigned long insert_pos, insert_len, i, l, old_seqlen, insert_start,
    do_cmpl, olen, site, pastart, paend, poss;
    char theinsert[10000], cpch, dir, *r;
    SEQCOMP *p, *q;

    old_seqlen = node->seqlen;
    insert_prob = get_random_double(1.0);

    if (repeat_id == RANDINS) /* insert random charactors, not interspersed repeats */
        threshold = node->ins_threshold * node->ins_multiplier;
    else if (repeat_id < RepeatNum)                   /* insert repeats */
        threshold = node->rp_insertion[repeat_id];
    else return ;

    if (insert_prob < threshold) {
        insert_pos = get_random_int(node->seqlen);
        if (insert_pos < node->seqlen && node->mut_prob[insert_pos] >= 1.0) {
            total = node->ins_func[SUMM];
            if (repeat_id == RANDINS)  /* determine what to insert, random char */
            {
                inslen = get_random_double(total);
                for (insert_len = 1; node->ins_func[insert_len] < inslen;)
                    insert_len++;
                for (i = 0; i < insert_len; i++)
                    theinsert[i] = get_random_char(RNDCHAR, 0);
                theinsert[i] = '\0';
            } else { /* insert repeats */
                l = strlen((RepeatConsensus)[repeat_id]);
                insert_len = lrand48() % (l - 2) + 1;
                insert_start = lrand48() % (l - insert_len - 1);
                do_cmpl = lrand48() % 2;
                if (do_cmpl) {
                    for (i = insert_start; i < insert_start + insert_len; i++) {
                        cpch = complement((RepeatConsensus)[repeat_id][i]);
                        if (isupper(cpch))
                            cpch = tolower(cpch);
                        theinsert[insert_start + insert_len - i - 1] = cpch;
                    }
                    theinsert[insert_len] = '\0';
                } else {
                    for (i = insert_start; i < insert_start + insert_len; i++) {
                        cpch = (RepeatConsensus)[repeat_id][i];
                        if (isupper(cpch))
                            cpch = tolower(cpch);
                        theinsert[i - insert_start] = cpch;
                    }
                    theinsert[insert_len] = '\0';
                }
            }

            old_vector = (double *)ckalloc((size_t)(node->seqlen * sizeof(double)));
            for (i = 0; i < node->seqlen; i++)
                old_vector[i] = node->mut_prob[i];
            node->seqlen += insert_len;
            free(node->mut_prob);
            node->mut_prob = (double *)ckalloc((size_t)(node->seqlen * sizeof(double)));
            for (i = 0; i < insert_pos; i++)
                node->mut_prob[i] = old_vector[i];
            for (i = insert_pos; i < insert_pos + insert_len; i++)
                node->mut_prob[i] = 1.0;
            for (i = insert_pos; i < old_seqlen; i++)
                node->mut_prob[i + insert_len] = old_vector[i];
            free(old_vector);

            /* insert theinsert to the alignment
               find the position according to insert_pos */

            p = node->alignment;
            q = p->next;
            while (q != NULL && (p->start + p->size <= insert_pos)) {
                p = q;
                q = q->next;
            }

            site = 0;
            for (i = 0; i < insert_pos - p->start;) {
                if (p->text[site] != '-')
                    i++;
                site++;  /* site is the insertion site */
            }

            dir = p->strand;
            pastart = p->alistart;
            paend = p->aliend;
            olen = p->aliend - p->alistart + 1;
            poss = (dir == '+') ? p->alistart + site
                   : p->alistart + (p->aliend - p->alistart - site + 1);
            p->aliend += insert_len;
            r = (char *)ckalloc((size_t)(olen + insert_len + 1));
            if (site != 0)
                memcpy(r, p->text, (size_t)site);
            memcpy(r + site, theinsert, (size_t)insert_len);
            strcpy(r + site + insert_len, (p->text) + site);
            free(p->text);
            p->text = r;

            for (p = node->alignment, i = p->start; p != NULL; p = p->next) {
                p->start = i;
                p->size = count_base(p->text, strlen(p->text));
                i += p->size;
            }
            node->seqlen = i;

            for (p = node->alignment; p != NULL; p = p->next) {
                if (p->alistart > pastart) {
                    p->alistart += insert_len;
                    p->aliend += insert_len;
                }
            }
            /* insert dashes to other visited nodes */
            insert_dash(TheTree, poss, insert_len, node->nid);
        }
    }
    return ;
}

/*-------------------------
      do deletion 
 -------------------------*/

void do_deletion(TNODE *node) {
    double delete_prob, *old_vector, total, dellen;
    unsigned long delete_pos, delete_len, i, old_seqlen, j, site, ss;
    SEQCOMP *p, *q;

    delete_prob = get_random_double(1.0);
    if (node->seqlen > 0 && delete_prob < node->del_threshold * node->del_multiplier) {
        delete_pos = get_random_int(node->seqlen);
        if (node->mut_prob[delete_pos] >= 1.0) {
            total = node->del_func[SUMM];
            dellen = get_random_double(total);
            for (delete_len = 1; node->del_func[delete_len] < dellen;)
                delete_len++;
            if (delete_pos + delete_len > node->seqlen)
                delete_len = node->seqlen - delete_pos;
            for (i = 0; i < delete_len && node->mut_prob[delete_pos + i] >= 1.0;)
                i++;
            delete_len = i;
            old_seqlen = node->seqlen;

            /* delete sequence -- add dashes
               find the deletion position according to delete_pos */
            for (p = node->alignment, q = p->next;
                 q != NULL && q->start <= delete_pos;
                 q = q->next)
                p = q;

            site = 0;
            for (i = 0; i < delete_pos - p->start;) {
                if (p->text[site] != '-')
                    i++;
                site++;         /* site is the deletion site */
            }
            /* deleted position changes to dash in the alignment */
            for (i = 0, j = 0, ss = site; i < delete_len; j++) {
                if (strlen(p->text) == ss + j) {
                    if (p->next == NULL) {
                        delete_len = i;
                        break;
                    }
                    p = p->next;
                    j = 0; ss = 0;
                }
                if (p->text[ss + j] != '-') {
                    p->text[ss + j] = '-';
                    i++;
                }
            }

            for (p = node->alignment, i = p->start; p != NULL; p = p->next) {
                p->start = i;
                p->size = count_base(p->text, strlen(p->text));
                i += p->size;
            }
            node->seqlen = i;

            old_vector = (double *)ckalloc((size_t)(sizeof(double) * (old_seqlen)));
            for (i = 0; i < old_seqlen; i++)
                old_vector[i] = node->mut_prob[i];
            free(node->mut_prob);
            node->mut_prob = (double *)ckalloc((size_t)(node->seqlen * sizeof(double)));
            for (i = 0; i < delete_pos; i++)
                node->mut_prob[i] = old_vector[i];
            for (i = delete_pos; i < node->seqlen; i++)
                node->mut_prob[i] = old_vector[delete_len + i];
            free(old_vector);
        }
    }
    return ;
}

/* get the opposite strand direction */
static char revdir(char orig) {
    return ((orig == '+') ? '-' : '+');
}

/*-------------------------
      do inversion 
 -------------------------*/

void do_inversion(TNODE* node, int mininvlen) {
    double invert_prob, total, invlen;
    unsigned long invert_pos, invert_len, i, j, site, ss, endsite;
    SEQCOMP *p, *q, *endp, *startp, *p1, *p2;
    char *temp_str;
    p1 = p2 = NULL;

    invert_prob = get_random_double(1.0);
    if (node->seqlen > 0 && invert_prob < node->inv_threshold * node->inv_multiplier) {
        invert_pos = get_random_int(node->seqlen);
        if (node->mut_prob[invert_pos] >= 1.0) {
            total = node->inv_func[SUMM];
            invlen = get_random_double(total);
            for (invert_len = 1; node->del_func[invert_len] < invlen; )
                invert_len++;
            invert_len = invert_len + mininvlen;
            if (invert_pos + invert_len > node->seqlen)
                invert_len = node->seqlen - invert_pos;
            for (i = 0; i < invert_len && node->mut_prob[invert_pos + i] >= 1.0;)
                i++;
            if (i < 2) /* too short */
                return ;
            else
                invert_len = i;

            /* start to do inversion here */
            p = node->alignment;
            q = p->next;
            while (q != NULL && q->start <= invert_pos) {
                p = q;
                q = q->next;
            }
            startp = p;
            site = 0;
            for (i = 0; i < invert_pos - p->start;) {
                if (p->text[site] != '-')
                    i++;
                site++;     /* site is the inversion site (offset) in startp */
            }

            for (i = 0, j = 0, ss = site; i < invert_len; j++) {
                if (strlen(p->text) == ss + j) {
                    if (p->next == NULL) {
                        invert_len = i;
                        p = p->next;
                        break;
                    }
                    p = p->next;
                    ss = j = 0;
                }
                if (p->text[ss + j] != '-')
                    i++;
            }
            endp = p;

            endsite = (startp != endp) ? j : (site + j); /* offset in endp */

            if (startp != endp) {
                if (site == 0 && startp != node->alignment) {
                    for (p = node->alignment; p->next != startp;)
                        p = p->next;
                    startp = p;
                } else {
                    if (startp == node->alignment && site == 0)
                        site++;
                    p2 = startp->next;
                    p1 = (SEQCOMP *)ckalloc(sizeof(SEQCOMP));
                    p1->strand = startp->strand;
                    p1->text = copy_string(startp->text + site);
                    temp_str = startp->text;
                    startp->text = copy_substring(temp_str, site);
                    free(temp_str);

                    if (startp->strand == '+') {
                        startp->aliend = startp->alistart + strlen(startp->text) - 1;
                        p1->alistart = startp->aliend + 1;
                        p1->aliend = p1->alistart + strlen(p1->text) - 1;
                    } else {
                        p1->alistart = startp->alistart;
                        p1->aliend = p1->alistart + strlen(p1->text) - 1;
                        startp->alistart = p1->aliend + 1;
                        startp->aliend = startp->alistart + strlen(startp->text) - 1;
                    }
                    p1->next = p2;
                    startp->next = p1;
                }
                /* break endp alignment comp */
                if (endp != NULL) {
                    if (endsite == strlen(endp->text)) {
                        endp = endp->next;
                    } else {
                        p2 = endp->next;
                        p1 = (SEQCOMP *)ckalloc(sizeof(SEQCOMP));
                        p1->strand = endp->strand;
                        p1->text = copy_string(endp->text + endsite);
                        temp_str = endp->text;
                        endp->text = copy_substring(temp_str, endsite);
                        free(temp_str);

                        if (endp->strand == '+') {
                            endp->aliend = endp->alistart + strlen(endp->text) - 1;
                            p1->alistart = endp->aliend + 1;
                            p1->aliend = p1->alistart + strlen(p1->text) - 1;
                        } else {
                            p1->alistart = endp->alistart;
                            p1->aliend = p1->alistart + strlen(p1->text) - 1;
                            endp->alistart = p1->aliend + 1;
                            endp->aliend = endp->alistart + strlen(endp->text) - 1;
                        }
                        p1->next = p2;
                        endp->next = p1;
                        endp = p1;
                    }
                }

                /* revert the inner part */
                p = startp->next;
                p2 = NULL;
                while (p != endp) {
                    if (strlen(p->text) == 0) {
                        p = p->next;
                        continue;
                    }
                    p1 = (SEQCOMP *)ckalloc(sizeof(SEQCOMP));
                    p1->strand = revdir(p->strand);
                    p1->text = rev_comp_string(p->text);
                    p1->alistart = p->alistart;
                    p1->aliend = p->aliend;
                    p1->next = p2;
                    p2 = p1;
                    p = p->next;
                }
                p = startp;
                while (p->next != endp)
                    p = p->next;
                p->next = NULL;
                p2 = p1;
                while (p2->next != NULL)
                    p2 = p2->next;
                p2->next = endp;
                p = startp->next;
                startp->next = NULL;
                free_comp_list(p);
                startp->next = p1;
            } else { /* startp == endp */
                if (endsite == strlen(startp->text)) {
                    if (site == 0) {
                        temp_str = rev_comp_string(startp->text);
                        free(startp->text);
                        startp->text = temp_str;
                        startp->strand = revdir(startp->strand);
                    } else {
                        p1 = (SEQCOMP *)ckalloc(sizeof(SEQCOMP));
                        temp_str = copy_string(startp->text + site);
                        p1->strand = revdir(startp->strand);
                        p1->text = rev_comp_string(temp_str);
                        free(temp_str);
                        temp_str = startp->text;
                        startp->text = copy_substring(temp_str, site);
                        free(temp_str);
                        p1->next = startp->next;
                        startp->next = p1;
                        if (startp->strand == '+') {
                            startp->aliend = startp->alistart + strlen(startp->text) - 1;
                            p1->alistart = startp->aliend + 1;
                            p1->aliend = p1->alistart + strlen(p1->text) - 1;
                        } else {
                            p1->alistart = startp->alistart;
                            p1->aliend = p1->alistart + strlen(p1->text) - 1;
                            startp->alistart = p1->aliend + 1;
                            startp->aliend = startp->alistart + strlen(startp->text) - 1;
                        }
                    }
                } else { /* three comp */
                    if (site == 0) {
                        p1 = (SEQCOMP *)ckalloc(sizeof(SEQCOMP));
                        p1->text = copy_string(startp->text + endsite);
                        p1->strand = startp->strand;
                        startp->strand = revdir(startp->strand);
                        temp_str = copy_substring(startp->text, endsite);
                        free(startp->text);
                        startp->text = rev_comp_string(temp_str);
                        free(temp_str);
                        p1->next = startp->next;
                        startp->next = p1;
                        if (startp->strand == '-') {
                            startp->aliend = startp->alistart + strlen(startp->text) - 1;
                            p1->alistart = startp->aliend + 1;
                            p1->aliend = p1->alistart + strlen(p1->text) - 1;
                        } else {
                            p1->alistart = startp->alistart;
                            p1->aliend = p1->alistart + strlen(p1->text) - 1;
                            startp->alistart = p1->aliend + 1;
                            startp->aliend = startp->alistart + strlen(startp->text) - 1;
                        }
                    } else {
                        p1 = (SEQCOMP *)ckalloc(sizeof(SEQCOMP));
                        temp_str = (char *)ckalloc((size_t)(endsite - site + 1));
                        memcpy(temp_str, startp->text + site, (size_t)(endsite - site));
                        temp_str[endsite - site] = '\0';
                        p1->strand = revdir(startp->strand);
                        p1->text = rev_comp_string(temp_str);
                        free(temp_str);
                        p2 = (SEQCOMP *)ckalloc(sizeof(SEQCOMP));
                        p1->next = p2;
                        p2->strand = startp->strand;
                        p2->text = copy_string(startp->text + endsite);
                        p2->next = startp->next;
                        startp->next = p1;
                        temp_str = startp->text;
                        startp->text = copy_substring(temp_str, site);
                        free(temp_str);

                        if (startp->strand == '+') {
                            p1->alistart = startp->alistart + site;
                            p1->aliend = p1->alistart + strlen(p1->text) - 1;
                            p2->alistart = p1->aliend + 1;
                            p2->aliend = p2->alistart + strlen(p2->text) - 1;
                            startp->aliend = startp->alistart + strlen(startp->text) - 1;
                        } else {
                            p2->alistart = startp->alistart;
                            p2->aliend = p2->alistart + strlen(p2->text) - 1;
                            p1->alistart = p2->aliend + 1;
                            p1->aliend = p1->alistart + strlen(p1->text) - 1;
                            startp->alistart = p1->aliend + 1;
                            startp->aliend = startp->alistart + strlen(startp->text) - 1;
                        }
                    }
                }
            }

            for (p = node->alignment, i = p->start; p != NULL; p = p->next) {
                p->start = i;
                p->size = count_base(p->text, strlen(p->text));
                i += p->size;
            }
            node->seqlen = i;
        }
    }
    return ;
}

/* copy alignment component list, return the head */

SEQCOMP* copy_seqcomp(SEQCOMP *sc) {
    SEQCOMP *p, *q, *end;

    if (sc == NULL)
        return NULL;

    p = (SEQCOMP *)ckalloc(sizeof(SEQCOMP));
    q = p;
    p->strand = sc->strand;
    p->start = sc->start;
    p->size = sc->size;
    p->alistart = sc->alistart;
    p->aliend = sc->aliend;

    p->text = copy_string(sc->text);
    p->next = NULL;
    for (sc = sc->next; sc != NULL; sc = sc->next) {
        end = (SEQCOMP *)ckalloc(sizeof(SEQCOMP));
        end->strand = sc->strand;
        end->start = sc->start;
        end->size = sc->size;
        end->alistart = sc->alistart;
        end->aliend = sc->aliend;
        end->text = copy_string(sc->text);
        end->next = NULL;
        q->next = end;
        q = end;
    }
    return p;
}

/*---------------------------------------------------
  evolve from father node to child node.
  perform substitution, insertion, deletion and inversion
 ---------------------------------------------------*/

void evolve(TNODE *old, TNODE *new) {
    unsigned long effective_length;
    unsigned int rep, i;
    (void)fprintf(stderr, ".");

    new->visited = 1; /* visited */

    new->alignment = copy_seqcomp(old->alignment);
    if (new->alignment == NULL)
        fatal("evolving error");

    new->seqlen = old->seqlen;

    new->ins_threshold = old->ins_threshold;
    new->del_threshold = old->del_threshold;
    new->inv_threshold = old->inv_threshold;
    new->del_func = old->del_func;
    new->inv_func = old->inv_func;
    new->ins_func = old->ins_func;

    new->mut_prob = (double *)ckalloc((size_t)sizeof(double) * (new->seqlen));
    for (i = 0; i < new->seqlen; i++)
        new->mut_prob[i] = old->mut_prob[i];
    if (MotifLossProb > 0) {
        if (get_random_double(1.0) < MotifLossProb) {
            for (i = 0; i < new->seqlen; i++)
                new->mut_prob[i] = 1.0;
        }
    }

    do_substitution(new);

    effective_length = (myroot_length > 0) ? myroot_length : old->seqlen;

    for (i = 0; i < ROUND(new->distance * old->seqlen); i++)
        do_insertion(new, RANDINS);

    for (i = 0; i < ROUND(new->distance * old->seqlen); i++)
        do_deletion(new);

    for (i = 0; i < ROUND(new->distance * effective_length); i++) {
        for (rep = 0; rep < RepeatNum; rep++)
            do_insertion(new, rep);
    }

    for (i = 0; i < ROUND(new->distance * old->seqlen); i++ )
        do_inversion(new, MinInvLength);

    if (same_string(new->name, "MYROOT"))
        myroot_length = new->seqlen;

    return ;
}

/*-----------------------------------------------
  fill sequence and alignment of each tree node,
  based on evolutionary operations
 ----------------------------------------------*/

void fill_node(TNODE *node) {
    if (node == NULL)
        return ;
    if (node->lchild != NULL) {
        evolve(node, node->lchild);
        fill_node(node->lchild);
    }
    if (node->rchild != NULL) {
        evolve(node, node->rchild);
        fill_node(node->rchild);
    }
    return ;
}

/*--------------------------------
  evolve throught the given tree
 --------------------------------*/

void evolve_through_tree() {
    unsigned long i;

    SEQCOMP *p = (SEQCOMP *)ckalloc(sizeof(SEQCOMP));

    p->next = NULL;
    p->strand = '+';
    p->start = 0;
    p->size = strlen(TheSequence);
    p->alistart = 0;             /* zero based */
    p->aliend = p->size - 1;     /* no dash in the alignment now */
    p->text = copy_string(TheSequence);    /* copy root sequence */

    TheTree->alignment = p;
    TheTree->seqlen = p->size;

    TheTree->ins_threshold = TheInsertThreshold;
    TheTree->del_threshold = TheDeleteThreshold;
    TheTree->inv_threshold = TheInvertThreshold;
    TheTree->mut_prob = (double *)ckalloc((size_t)(sizeof(double) * (TheTree->seqlen)));

    for (i = 0; i < TheTree->seqlen; i++)  /* copy mut_prob of root */
        TheTree->mut_prob[i] = TheMutationProbability[i];

    TheTree->ins_func = TheInsFunc;
    TheTree->del_func = TheDelFunc;
    TheTree->inv_func = TheInvFunc;

    if (!same_string(TheTree->name, "ROOT")) {
        ckfree(TheTree->name);
        TheTree->name = copy_string("ROOT");
    }

    TheTree->visited = 1;

    print_argv0();
    (void)fprintf(stderr, "Evolving through the phylogenetic tree...");

    fill_node(TheTree);  /* evolve each tree node */

    (void)fprintf(stderr, " Done!\n");

    return ;
}

