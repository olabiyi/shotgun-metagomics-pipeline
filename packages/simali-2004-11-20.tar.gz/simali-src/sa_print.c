/***********************************************************************/
/*                                                                     */
/*   sa_print.c                                                        */
/*                                                                     */
/*   This program produces the output of simali.                       */
/*   Sequences are in fasta format.                                    */
/*   Alignment is in maf format.                                       */
/*                                                                     */
/***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "head.h"
#include "maf.h"
#include "util.h"

#define CHARPERLINE 60      /* number of characters per line in fasta sequence file */

static int sp_num;          /* how many species we are going to invesitigate */
static int cut_num;         /* how many cut_site  */
static unsigned long cut_site[10000]; /* cut_site is the aliend position appears in the final alignment */
static TNODE* sp_nd[100];      /* specie's node in the tree */
static SEQCOMP* sp_pt[100];    /* pointer to specie's corresponding alignment comp */

/* get interested species according to their names.
   store the address of node and the pointer to their alignment list */

void get_species(TNODE *node) {
    if (node == NULL) return ;

    /* do recursively */
    get_species(node->rchild);
    get_species(node->lchild);

    /* The species we retain are: HUMAN CHIMP BABOON MOUSE RAT PIG COW CAT DOG */

    if ((node->name[0] == 'D' && node->name[1] == 'U')    /* auxiliary nodes we created before  */
        || (node->name[0] == 'I' && node->name[1] == 'N') /* we don't need them in the alignment */
        || (node->name[0] == 'A' && node->name[1] == 'N')
        || (node->name[0] == 'M' && node->name[1] == 'Y')
        || (node->name[0] == 'F' && node->name[1] == 'O')
        || (node->name[0] == 'R' && node->name[1] == 'O'))
        return ;
    else {   /* interested species */
        sp_nd[sp_num] = node;
        sp_pt[sp_num] = node->alignment;
        sp_num++;
    }
    return ;
}

static int compar(unsigned long *a, unsigned long *b) {
    if (*a > *b)
        return 1;
    if (*a < *b)
        return -1;
    return 0;
}

/* get different cut_sites and then sort them */

void cut_ali(void) {
    int i, j;
    SEQCOMP *p;

    for (i = 0; i < sp_num; i++) {
        p = sp_nd[i]->alignment;
        while (p != NULL) {
            for (j = 0; j < cut_num; j++) {
                if (cut_site[j] == p->aliend)
                    break;
            }
            if (j == cut_num) {
                cut_site[cut_num] = p->aliend;
                cut_num++;
            }
            p = p->next;
        }
    }
    /* sort cut_site[] */
    qsort(cut_site, cut_num, sizeof(unsigned long), (const void *)compar);

    return ;
}

/* remove dashes of a given sequence
   if all the chars are dashes, return NULL */

static char *remove_dash(char *str) {
    char *newstr;
    unsigned long i, len, j;

    len = strlen(str);
    newstr = (char *)ckalloc(sizeof(char) * (len + 1));

    for (i = 0, j = 0; i < len; i++) {
        if (str[i] != '-')
            newstr[j++] = str[i];
    }
    if (j == 0) /* all are dashes */
    {
        free(newstr);
        return NULL;
    } /* else, we don't free,
         free in other places. */
    newstr[j] = '\0';
    return newstr;
}

/*------------------------------------------
  write the sequence files for every specie, 
  in fasta format. 60 characters each line 
  -----------------------------------------*/

void write_seq_fasta(int dn) {
    unsigned long j;
    int i;
    char *s;
    char c;
    FILE *fseq, *tmpfile;
    SEQCOMP *p;

    print_argv0();
    (void)fprintf(stderr, "Writing the sequences in fasta format... ");

    for (i = 0; i < sp_num; i++) {
        tmpfile = ckopen("_tmpfile", "w");
        fprintf(tmpfile, ">%s\n", sp_nd[i]->name);
        p = (sp_nd[i])->alignment;
        while (p != NULL) {
            s = remove_dash(p->text);
            if (s == NULL) {
                p = p->next;
                continue;
            }
            fprintf(tmpfile, "%s", s);
            free(s);
            p = p->next;
        }
        (void)fprintf(stderr, "%s...", sp_nd[i]->name );
        fclose(tmpfile);

        /* format the fasta seq file. 60 chars per line */
        fseq = ckopen(sp_nd[i]->name, "w");
        tmpfile = ckopen("_tmpfile", "r");
        c = getc(tmpfile);
        while (!feof(tmpfile)) {
            if (c == '>') {
                while (c != '\n') {
                    fputc(c, fseq);
                    c = fgetc(tmpfile);
                }
                fputc('\n', fseq);
                c = fgetc(tmpfile);
            } else {
                for (j = 0; j < CHARPERLINE && c != EOF; j++) {
                    fputc(c, fseq);
                    c = fgetc(tmpfile);
                }
                if (j == CHARPERLINE)
                    fputc('\n', fseq);
            }
        }
        fclose(tmpfile);
        fclose(fseq);

        do_cmd("rm _tmpfile");
        do_cmd("mv %s dataset%03d", sp_nd[i]->name, dn);
    }
    (void)fprintf(stderr, " Done!\n");

    return ;
}

void maf_rm_dash(struct mafAli *a) {

    struct mafComp *c;
    char sc[20][50000];
    int i, p, k;

    for (i = p = 0; a->components->text[i] != '\0'; i++) {
        for (c = a->components; c != NULL; c = c->next) {
            if (c->text[i] != '-')
                break;
        }
        if ( c != NULL ) {
            for (k = 0, c = a->components; c != NULL; c = c->next, k++)
                sc[k][p] = c->text[i];
            p++;
        }
    }
    for (k = 0, c = a->components; c != NULL; c = c->next, k++) {
        c->text = (char *)ckrealloc(c->text, (size_t)p + 1);
        memcpy(c->text, sc[k], (size_t)p);
        c->text[p] = '\0';
    }
}

/*--------------------------------------------
  write the alignment components in maf format
  -------------------------------------------*/

void write_maf(int dn) {
    struct mafAli A, *a;
    struct mafComp *c1, *c2;
    unsigned long len, ln;
    int cutn, spn;
    char *temp_str, *str;
    FILE *maffile;
    SEQCOMP *p, *p1;

    c1 = c2 = NULL;
    a = &A;
    print_argv0();
    (void)fprintf(stderr, "Writing the alignment in maf format... ");

    maffile = fopen("simali.output.maf", "w");
    mafWriteStart(maffile, "simali-indels-inversions");

    for (cutn = 0; cutn < cut_num; cutn++) {
        a->score = 0.0;   /* we don't have score. */

        /* get the text size of the a maf block, including dashes  */

        a->textSize = (cutn == 0) ? cut_site[0] + 1
                      : cut_site[cutn] - cut_site[cutn - 1];

        for (spn = 0; spn < sp_num; spn++) {
            len = a->textSize;
            if (spn == 0) /* first specie in the block  */
            {
                c1 = (struct mafComp *)ckalloc(sizeof(struct mafComp));
                a->components = c1;
                c1->next = NULL;
                c2 = c1;
            } else          /* append to the exsiting list */
            {
                c1 = (struct mafComp *)ckalloc(sizeof(struct mafComp));
                c1->next = NULL;
                c2->next = c1;
                c2 = c1;
            }

            c1->src = copy_string(sp_nd[spn]->name);

            /* find sp_pt[spn] */

            p = sp_nd[spn]->alignment;
            while (p != NULL && (p->alistart > cut_site[cutn] || p->aliend < cut_site[cutn]))
                p = p->next;

            if (p->aliend == cut_site[cutn]) {
                c1->strand = p->strand;
                c1->text = copy_string(p->text);
                c1->srcSize = sp_nd[spn]->seqlen;
                c1->size = p->size;
                c1->start = p->start;
            } else { /* break */
                p1 = (SEQCOMP *)ckalloc(sizeof(SEQCOMP));
                p1->strand = p->strand;
                if (p->strand == '+') {
                    p1->text = copy_string(p->text + len);
                    p1->next = p->next;
                    p->next = p1;
                    temp_str = copy_substring(p->text, len);
                    free(p->text);
                    p->text = temp_str;
                    p1->start = p->start + count_base(p->text, len);
                    p1->size = count_base(p1->text, strlen(p1->text));
                    p1->aliend = p->aliend;
                    p->aliend = p->alistart + len - 1;
                    p1->alistart = p->aliend + 1;
                    p->size = count_base(p->text, strlen(p->text));
                } else {
                    ln = strlen(p->text) - len;
                    p1->text = copy_string(p->text + ln);
                    p1->next = p->next;
                    p->next = p1;
                    temp_str = copy_substring(p->text, ln);
                    free(p->text);
                    p->text = temp_str;
                    p1->start = p->start + count_base(p->text, ln);
                    p1->size = count_base(p1->text, strlen(p1->text));
                    p1->alistart = p->alistart;
                    p1->aliend = p1->alistart + strlen(p1->text) - 1;
                    p->alistart = p1->aliend + 1;
                    p->aliend = p->alistart + strlen(p->text) - 1;
                    p->size = count_base(p->text, strlen(p->text));
                    p = p1;
                }

                c1->strand = p->strand;
                c1->text = copy_string(p->text);
                c1->srcSize = sp_nd[spn]->seqlen;
                c1->size = p->size;
                c1->start = p->start;
            }
            if (c1->strand == '-') {
                c1->start = c1->srcSize - c1->start - c1->size;
                str = rev_comp_string(c1->text);
                free(c1->text);
                c1->text = str;
            }
        }

        maf_rm_dash(a); /* remove all-dash column */

        /* remove maf component which contains all dashes */
        for (c1 = a->components; c1 != NULL && c1->size == 0; c1 = c2) {
            c2 = c1->next;
            c1->next = NULL;
            free(c1->src);
            free(c1->text);
            free(c1);
        }
        a->components = c1;
        if (c1 != NULL) {
            for (c2 = c1->next; c2 != NULL; c2 = c1->next) {
                if (c2->size == 0) {
                    c1->next = c2->next;
                    c2->next = NULL;
                    free(c2->src);
                    free(c2->text);
                    free(c2);
                } else
                    c1 = c1->next;
            }
        }

        /* write this mafAli block to file */
        if (a->components != NULL) {
            mafWrite(maffile, a);
        }

        /* free the space of maf component list */
        for (c1 = a->components; c1 != NULL; c1 = c2) {
            c2 = c1->next;
            free(c1->src);
            free(c1->text);
            free(c1);
        }
    }
    fclose(maffile);

    do_cmd("mv simali.output.maf dataset%03d", dn);
    (void)fprintf(stderr, "Done!\n");

    return ;
}

/*----------------------------------------------
  print the simulation result.
  1) write the simulated sequences in fasta files
  2) write the 'true' alignment in a maf file
  mv all of them into a directory
  ----------------------------------------------*/

void print_result(int dn) {
    sp_num = 0;     /* set init sp_num */
    cut_num = 0;    /* set init cut_num */

    get_species(TheTree);
    cut_ali();

    do_cmd("rm -rf dataset%03d", dn); /* in case that...  */
    do_cmd("mkdir dataset%03d", dn);

    write_seq_fasta(dn);
    write_maf(dn);

    return ;
}

