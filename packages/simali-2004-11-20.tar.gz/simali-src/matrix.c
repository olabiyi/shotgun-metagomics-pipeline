/********************************************************************/
/*                                                                  */
/*   matrix.c                                                       */
/*                                                                  */
/*   procedures of basic matrix operations.                         */
/*   part of the code are from Mathieu Blanchette's code            */
/*                                                                  */
/********************************************************************/

#include <math.h>
#include "head.h"
#include "util.h"

int prepare_matrix(void) {
    int i, j;
    if (TheRateMatrix == NULL) {
        if (TheDNAmodel == NULL || strncmp(TheDNAmodel, "HKY", 3) != 0 )
            return FALSE;
        return TRUE;
    }
    if (TheMatrix == NULL) {
        TheMatrix = (double **)ckalloc(MAX_ALPH * sizeof(double *));
        for (i = 0; i < MAX_ALPH; i++)
            TheMatrix[i] = (double *)ckalloc(MAX_ALPH * sizeof(double));
    }
    for (j = 0; j < BASE_NUM; j++) {
        TheMatrix[(int)TheAlphabet[0]][(int)TheAlphabet[j]] = TheRateMatrix[0][j];
        for ( i = 1; i < BASE_NUM; i++ )
            TheMatrix[(int)TheAlphabet[i]][(int)TheAlphabet[j]] = TheMatrix[(int)TheAlphabet[i - 1]][(int)TheAlphabet[j]]
                    + TheRateMatrix[i][j];
    }
    for (j = 0; j < BASE_NUM; j++)
        TheMatrix[SUMM][(int)TheAlphabet[j]] = TheMatrix[(int)TheAlphabet[BASE_NUM - 1]][(int)TheAlphabet[j]];
    return TRUE;
}

void copy_matrix(double **m1, double **m2) {
    int i, j;
    for (i = 0; i < BASE_NUM; i++)
        for (j = 0; j < BASE_NUM; j++)
            m1[i][j] = m2[i][j];
    return ;
}

void transpose_matrix(double **m) {
    double **copy;
    int i, j;
    copy = (double **)ckalloc(BASE_NUM * sizeof(double *));
    for (i = 0; i < BASE_NUM; i++)
        copy[i] = (double *)ckalloc(BASE_NUM * sizeof(double));
    copy_matrix(copy, m);
    for (i = 0; i < BASE_NUM; i++)
        for (j = 0; j < BASE_NUM; j++)
            m[i][j] = copy[j][i];
    for (i = 0; i < BASE_NUM; i++)
        free(copy[i]);
    free(copy);
}

int build_matrix(double t) {
    int i, j;
    double transition, transversion, total, PI, pihelp;
    double pi[MAX_ALPH];
    double A = 0.0;
    if (TheRateMatrix == NULL) {
        TheRateMatrix = (double **)ckalloc(BASE_NUM * sizeof(double *));
        for (i = 0; i < BASE_NUM; i++)
            TheRateMatrix[i] = (double *)ckalloc(BASE_NUM * sizeof(double));
    }
    for (i = 0; i < BASE_NUM; i++) {
        pi[(int)TheAlphabet[i]] = TheFreq[(int)TheAlphabet[i]];
        if (i > 0)
            pi[(int)TheAlphabet[i]] -= TheFreq[(int)TheAlphabet[i - 1]];
    }
    total = 0.0;
    for (i = 0; i < BASE_NUM; i++)
        total += pi[(int)TheAlphabet[i]];
    if ( total != 1.0)
        for (i = 0; i < BASE_NUM; i++)
            pi[(int)TheAlphabet[i]] = pi[(int)TheAlphabet[i]] / total;
    /* HKY model */
    /* M.Hasegawa, H.Kishino, and T.Yano.
       Dating of the human-ape splitting by a molecular 
       clock of mitochondrial DNA.
       Journal of Molecular Evolution, 21: 160-174, 1985. */
    if (strncmp(TheDNAmodel, "HKY", 3) == 0) {
        for (i = 0; i < BASE_NUM; i++) {
            for (j = 0; j < BASE_NUM; j++) {
                if ( (TheAlphabet[j] == 'A') || (TheAlphabet[j] == 'T') )
                    PI = pi['A'] + pi['T'];
                else
                    PI = pi['C'] + pi['G'];
                A = 1 + PI * (TransitionBias - 1.0);
                pihelp = pi[(int)TheAlphabet[j]];
                if (i == j)
                    TheRateMatrix[i][j] = pihelp + pihelp * (1 / PI - 1.0) * exp(( -(MeanSubstitution) * t * 1.0))
                                          + ((PI - pihelp) / PI) * exp(( -(MeanSubstitution) * t * A));
                else {
                    transition = pihelp + pihelp * (1.0 / PI - 1.0) * exp(( -(MeanSubstitution) * t * 1.0))
                                 - (pihelp / PI) * exp(( -(MeanSubstitution) * t * A));
                    transversion = pihelp * (1 - exp( -(MeanSubstitution) * t));
                    /* !! MATHIEU FIXED THIS: HE THOUGHT TRANSITION = A<->T and C<->G !! */
                    if (TheAlphabet[i] == 'A') {
                        if (TheAlphabet[j] == 'G')
                            TheRateMatrix[i][j] = transition;
                        else
                            TheRateMatrix[i][j] = transversion;
                    } else if (TheAlphabet[i] == 'C') {
                        if (TheAlphabet[j] == 'T')
                            TheRateMatrix[i][j] = transition;
                        else
                            TheRateMatrix[i][j] = transversion;
                    } else if (TheAlphabet[i] == 'G') {
                        if (TheAlphabet[j] == 'A')
                            TheRateMatrix[i][j] = transition;
                        else
                            TheRateMatrix[i][j] = transversion;
                    } else if (TheAlphabet[i] == 'T') {
                        if (TheAlphabet[j] == 'C')
                            TheRateMatrix[i][j] = transition;
                        else
                            TheRateMatrix[i][j] = transversion;
                    }
                }
            }
        }
    }
    transpose_matrix(TheRateMatrix);
    prepare_matrix();

    return 0;
}

