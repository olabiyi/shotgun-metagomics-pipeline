/* head.h */

#ifndef __HEAD_H__
#define __HEAD_H__

#define BASE_NUM 4
#define RNDCHAR  '+'
#define MAX_ALPH 128
#define SUMM     0
#define VERSION  1.0
#define CPG_MULTIPLICATIVE_FACTOR 10

typedef struct seq_comp  /* SEQCOMP: alignment component */
{
    struct seq_comp *next;
    char strand;            /* strand of sequence.  either + or - */
    unsigned long start;    /* start within sequence. zero based.
                               if strand is -, still relative to the start. 
                               different from maf comp */
    unsigned long size;	    /* size in the component (does not include dashes).  */
    unsigned long alistart; /* the start position in the alignment of this seq block */
    unsigned long aliend;   /* the end position in the alignment of this seq block */
    char *text;	            /* the sequence, including dashes. with '\0' in the end */
} SEQCOMP;

typedef struct tree_node  /* TNODE: nodes in evolutionary tree */
{
    struct tree_node *father;  /* father of the node. NULL for root */
    struct tree_node *lchild;  /* left child of the node. NULL for leaf */
    struct tree_node *rchild;  /* right child of the node. NULL for leaf */
    int nid;                   /* a unique identity of the node */
    double distance;           /* evolutionary distance (edge length) */
    double ins_multiplier;     /* insertion multiplier */
    double del_multiplier;     /* deletion multiplier */
    double inv_multiplier;     /* inversion multiplier */
    double ins_threshold;      /* insertion probability */
    double del_threshold;      /* deletion probability */
    double inv_threshold;      /* inversion probability */
    double *ins_func;          /* pointer to the insertion length distrib func */
    double *del_func;          /* pointer to the deletion length distrib func */
    double *inv_func;          /* pointer to the inversion length distrib func */
    double *mut_prob;          /* mutation probability of seq of each node */
    double rp_insertion[100];  /* insertion prob of each interspersed repeats family */
    char *name;                /* name of the node (species' names) */
    unsigned long seqlen;      /* does not include dashes */
    int visited;               /* visited tag during the evolution. init 0.
                                  when the node has been evolved, set to 1 */
    SEQCOMP *alignment;        /* the aligned sequence of the tree node */
} TNODE;

/* these variables are defined in sa_main.c */
extern unsigned long SequenceLen;
extern int SequenceNum;
extern TNODE *TheTree;
extern char *TheSequence;
extern double **TheRateMatrix;
extern double **TheMatrix;
extern char *TheAlphabet;
extern double *TheFreq;
extern double *TheInsFunc;
extern double *TheDelFunc;
extern double *TheInvFunc;
extern double TheInsertThreshold;
extern double TheDeleteThreshold;
extern double TheInvertThreshold;
extern double *TheMutationProbability;
extern char *TheDNAmodel;
extern double MeanSubstitution;
extern double TransitionBias;
extern double MotifLossProb;
extern int InsFuncDim;
extern int DelFuncDim;
extern int InvFuncDim;
extern int MinInvLength;
extern unsigned int RepeatNum;    
extern char RepeatConsensus[100][10000];

/* entries in sa_input.c */
void read_in_para(char *para_file);
void create_root(void);
void create_mutation_prob(void);
void free_para_space(void);
void read_extra_informations(char *fname);
void modify_para_file(char *fin, char *fout);

/* entries in sa_evolve.c */
void evolve_through_tree(void);

/* entries in sa_print.c */
void print_result(int num);

/* entries in tree.c */
TNODE* get_tree(char *tree_str);
void free_comp_list(SEQCOMP *p);
void free_tree_space(TNODE *root);
void free_tree_ali(TNODE *root);

/* entries in matrix.c */
int build_matrix(double dist);

#endif

