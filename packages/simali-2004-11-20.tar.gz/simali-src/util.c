/***********************************************************************/
/*                                                                     */
/*   util.c                                                            */
/*                                                                     */
/*   Utility procedures used in the program.                           */
/*   Most part is copied from TBA source code.                         */
/*                                                                     */
/***********************************************************************/

#include <stdarg.h>
#include "util.h"
#include "head.h"

extern char *argv0;

const char *const RED = "\033[0;31m";
const char *const BLUE = "\033[0;34m";
const char *const GREEN = "\033[0;32m";
const char *const NORMALCOLOR = "\033[0m";

/* print_argv0 ---------------------------------------- print name of program */
void print_argv0(void) {
    if (argv0) {
        char *p = strrchr(argv0, '/');
        (void)fprintf(stderr, "%s%s:%s ", GREEN, p ? p + 1 : argv0, NORMALCOLOR);
    }
}

void print_a_line() {
    (void)fprintf(stderr, "%s---------------------------------%s\n", RED, NORMALCOLOR);
}

/* fatal ---------------------------------------------- print message and die */
void fatal(const char *msg) {
    fatalf("%s", msg);
}

/* fatalf --------------------------------- format message, print it, and die */
void fatalf(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fflush(stdout);
    print_argv0();
    (void)vfprintf(stderr, fmt, ap);
    (void)fputc('\n', stderr);
    va_end(ap);
    exit(1);
}

/* ckopen -------------------------------------- open file; check for success */
FILE *ckopen(const char *name, const char *mode) {
    FILE *fp;

    if ((fp = fopen(name, mode)) == NULL)
        fatalf("Cannot open %s.", name);
    return fp;
}

/* ckalloc -------------------------------- allocate space; check for success */
void *ckalloc(size_t amount) {
    void *p;

    if ((long)amount < 0)                                  /* was "<= 0" -CR */
        fatal("ckalloc: request for negative space.");
    if (amount == 0)
        amount = 1; /* ANSI portability hack */
    if ((p = malloc(amount)) == NULL)
        fatalf("Ran out of memory trying to allocate %lu.",
               (unsigned long)amount);
    return p;
}

/* ckallocz -------------------- allocate space; zero fill; check for success */
void *ckallocz(size_t amount) {
    void *p = ckalloc(amount);
    memset(p, 0, amount);
    return p;
}

/* same_string ------------------ determine whether two strings are identical */
bool same_string(const char *s, const char *t) {
    return (strcmp(s, t) == 0);
}

/* copy_string ---------------------- save string s somewhere; return address */
char *copy_string(const char *s) {
    char *p = ckalloc(strlen(s) + 1);    /* +1 to hold '\0' */
    return strcpy(p, s);
}

/* copy_substring ------------ save first n chars of string s; return address */
char *copy_substring(const char *s, int n) {
    char *p = ckalloc((size_t)n + 1);    /* +1 to hold '\0' */
    memcpy(p, s, (size_t)n);
    p[n] = 0;
    return p;
}

void ckfree(void *p) {
    if (p) free(p);
}

unsigned int roundup(unsigned int n, unsigned int m) {
    return ((n + (m - 1)) / m) * m;
}

void fatalfr(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fflush(stdout);
    print_argv0();
    (void)vfprintf(stderr, fmt, ap);
    (void)fprintf(stderr, ": %s\n", strerror(errno));
    va_end(ap);
    exit(1);
}

void *ckrealloc(void * p, size_t size) {
    p = p ? realloc(p, size) : malloc(size);
    if (!p)
        fatal("ckrealloc failed");
    return p;
}

unsigned long get_random_int(unsigned long bound) {
    unsigned long a;
    a = lrand48();
    if ( bound != 0)
        return (a % bound);
    return 0;
}

double get_random_double(double bound) {
    double a;
    a = drand48();
    return (a * bound);
}

char get_random_char(char old_value, double dist) {
    char value, real_old_value;
    int column, k;
    double random_number;

    value = real_old_value = old_value;

    if ( old_value == RNDCHAR ) {
        random_number = get_random_double(TheFreq[SUMM]);
        for ( k = 0; TheFreq[(int)TheAlphabet[k]] <= random_number;)
            k++;
        value = TheAlphabet[k];
    } else /* mutate a character */
    {
        if (TheDNAmodel != NULL) {
            if (dist <= 0.0)
                return old_value;
            build_matrix(dist);
            column = (int)old_value;
            random_number = get_random_double(TheMatrix[SUMM][column]);
            for (k = 0; TheMatrix[(int)TheAlphabet[k]][column] <= random_number;)
                k++;
            value = TheAlphabet[k];
        } else
            fatal("DNA Model not known!");
    }
    return value;
}

unsigned long count_base(char *p, unsigned long len) {
    unsigned long i, count = 0;
    for (i = 0; i < len; i++)
        if (p[i] != '-')
            count++;
    return count;
}


/* complement of a character */
char complement(char a) {
    switch (a) {
        case 'A': return 'T';
        case 'C': return 'G';
        case 'G': return 'C';
        case 'T': return 'A';
        case 't': return 'a';
        case 'a': return 't';
        case 'c': return 'g';
        case 'g': return 'c';
        case '-': return '-';
    }
    fatalf("illegal char, %c", a);
}

/* allocate space, revert and complement a given sequence */
char *rev_comp_string(char *s) {
    char *news;
    unsigned int i, j, len;
    len = strlen(s);
    news = (char *)ckalloc(sizeof(char) * (len + 1));
    for (i = 0, j = 0; i < len; i++, j++)
        news[i] = complement(s[len - 1 - j]);
    news[i] = '\0';
    return news;
}

void do_cmd(const char *fmt, ...) {
    char buf[10000];
    va_list ap;
    va_start(ap, fmt);
    (void)vsprintf(buf, fmt, ap);
    if (system(buf) != 0)
        fatalf("Command '%s' failed", buf);
    va_end(ap);
    return ;
}

